package com.model;

public interface InterestCalculator {

	public double interestCalculate(double amt);
}
