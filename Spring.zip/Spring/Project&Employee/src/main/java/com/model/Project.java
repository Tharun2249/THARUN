package com.model;

public class Project {

	private int pid;
	private String name;
}
