package com.example.Spring_Rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
