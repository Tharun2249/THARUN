package com.dao;

import com.model.Insurance;

public interface InsuranceDao {

	public void addInsurance(Insurance ins);
}
