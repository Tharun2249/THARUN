package com.dao;

import com.model.BankAccount;
import com.model.Insurance;

public interface BankDao {

	public void createAccount(BankAccount ba);
}
