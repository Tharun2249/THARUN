package com.example.spring_restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestaurantApplicationTests {

	@Test
	void contextLoads() {
	}

}
