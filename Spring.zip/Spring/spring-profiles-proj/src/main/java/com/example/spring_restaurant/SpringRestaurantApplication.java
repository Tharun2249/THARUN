package com.example.spring_restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestaurantApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestaurantApplication.class, args);
	}

}
