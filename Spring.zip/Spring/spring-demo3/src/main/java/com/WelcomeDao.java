package com;

public interface WelcomeDao {

	public String sayHello(String str);
	
	public void sayWelcome();
	
	public int calculate(int a,int b);
	
	public void venky();
}
